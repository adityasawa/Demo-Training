const express = require('express');
const connection = require('../connection');
const router = express.Router();
let auth = require('../services/authentication');

router.get('/details',auth.authenticateToken,(req,res,next)=>{
    let categoryCount;
    let testCount;
    let billCount;
    var query = "select count(id) as categoryCount from category";
    connection.query(query,(err,results)=>{
        if(!err){
            categoryCount = results[0].categoryCount;
        }
        else{
            return res.status(500).json(err);
        }
    })

    var query= "select count(id) as testCount from test";
    connection.query(query,(err,results)=>{
        if(!err){
            testCount = results[0].testCount;
        }
        else{
            return res.status(500).json(err);
        }
    })

    var query="select count(id) as billCount from invoice";
    connection.query(query,(err,results)=>{
        if(!err){
            billCount = results[0].billCount;
            let data = {
                category:categoryCount,
                test: testCount,
                bill: billCount
            };
            return res.status(200).json(data);
        }
        else{
            return res.status(500).json(err);
        }
    })
})

module.exports = router;