const express=require('express');
const connection = require('../connection');
const router = express.Router();
let auth=require('../services/authentication');
let checkRole=require('../services/checkRole');

router.post('/add',auth.authenticateToken,checkRole.checkRole,(req,res)=>{
    let test = req.body;
    let query = "insert into test (name,categoryId,description,price,status) values(?,?,?,?,'true')";
    connection.query(query,[test.name,test.categoryId,test.description,test.price],(err,results)=>{
        if(!err){
            return res.status(200).json({message:"Test added successfully"});
        }
        else{
            return res.status(500).json(err);
        }
    })
})

router.get('/get',auth.authenticateToken,(req,res,next)=>{
    let query= "select t.id,t.name,t.description,t.price,t.status,c.id as categoryId,c.name as categoryName from test as t INNER JOIN category as c where t.categoryId = c.id";
    connection.query(query,(err,results)=>{
        if(!err){
            return res.status(200).json(results);
        }
        else{
            return res.status(500).json(err);
        }
    })
})

router.get('/getByCategory/:id',auth.authenticateToken,(req,res,next)=>{
    const id = req.params.id;
    let query ="select id,name from test where categoryId=? and status='true'";
    connection.query(query,[id],(err,results)=>{
        if(!err){
            return res.status(200).json(results);
        }
        else{
            return res.status(500).json(err);
        }
    })
})

router.get('/getById/:id',auth.authenticateToken,(req,res,next)=>{
    const id = req.params.id;
    let query = "select id,name,description,price from test where id = ?";
    connection.query(query,[id],(err,results)=>{
        if(!err){
            return res.status(200).json(results[0]);
        }
        else{
            return res.status(500).json(err);
        }
    })
})

router.patch('/update',auth.authenticateToken,checkRole.checkRole,(req,res,next)=>{
    let test = req.body;
    let query = "update test set name=?,categoryId=?,description=?,price=? where id=?";
    connection.query(query,[test.name,test.categoryId,test.description,test.price,test.id],(err,results)=>{
        if(!err){
            if(results.affectedRows == 0){
                return res.status(404).json({message: "Test id not found"});
            }
            return res.status(200).json({message:"Test updated successfully"});
        }
        else{
            return res.status(500).json(err);
        }
    })
})

router.delete('/delete/:id',auth.authenticateToken,checkRole.checkRole,(req,res,next)=>{
    const id = req.params.id;
    let query="delete from test where id=?";
    connection.query(query,[id],(err,results)=>{
        if(!err){
            if(results.affectedRows == 0){
                return res.status(404).json({message: "Test id not found"});
            }
            return res.status(200).json({message:"Test deleted successfully"});
        }
        else{
            return res.status(500).json(err);
        }
    })
})

router.patch('/updateStatus',auth.authenticateToken,checkRole.checkRole,(req,res,next)=>{
    let user = req.body;
    let query = "update test set status=? where id=?";
    connection.query(query,[user.status,user.id],(err,results)=>{
        if(!err){
            if(results.affectedRows == 0){
                return res.status(404).json({message: "Test id not found"});
            }
            return res.status(200).json({message:"Test updated successfully"});
        }
        else{
            return res.status(500).json(err);
        }
    })
})

module.exports = router;